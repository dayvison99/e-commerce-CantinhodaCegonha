<?php
die('Access denied!');