<?php
add_action( 'theshopier_header_init', 'theshopier_header_toolbar', 1 );

add_action( 'theshopier_header_init', 'theshopier_header_body', 20 );

add_action( 'theshopier_header_init', 'theshopier_header_tablet', 20 );

?>
