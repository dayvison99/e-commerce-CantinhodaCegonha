<?php
/**
 * @package WordPress
 * @subpackage Nexthemes
 * @since Nexthemes 1.0
 */

require_once get_template_directory() . '/framework/theme.php';

$theshopier = new Theshopier();
$theshopier->init();
?>
