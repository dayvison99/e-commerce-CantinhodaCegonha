=== THE SHOPIER ===
Contributors: Nexthemes
Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar, fluid-layout, fixed-layout, custom-menu, full-width-template, rtl-language-support, sticky-post, theme-options, translation-ready
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 4.1
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Our 2015 default theme is clean, blog-focused, and designed for clarity. Twenty Fifteen's simple, straightforward typography is readable on a wide variety of screen sizes, and suitable for multiple languages. We designed it using a mobile-first approach, meaning your content takes center-stage, regardless of whether your visitors arrive by smartphone, tablet, laptop, or desktop computer.

== Installation ==

== Frequently Asked Questions ==

= Documentation =
Please read: http://demo.nexthemes.com/wordpress/theshopier/documentation/

= How do I add a description for my menu link in navigation? =

= Quick Specs =
